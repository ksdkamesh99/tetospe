package com.example.tetospe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    Button con;
    EditText te;
    TextToSpeech tts;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        con=(Button) findViewById(R.id.con);
        te=(EditText) findViewById(R.id.te);
        tts=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status==TextToSpeech.SUCCESS){
                    int ttsLang = tts.setLanguage(Locale.US);

                    if (ttsLang == TextToSpeech.LANG_MISSING_DATA
                            || ttsLang == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("TTS", "The Language is not supported!");
                    } else {
                        Log.i("TTS", "Language Supported.");
                    }
                    Log.i("TTS", "Initialization success.");
                }
                else{
                    Toast.makeText(MainActivity.this,"TTS initialisation failed",Toast.LENGTH_SHORT).show();
                }
            }
        });

        con.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(te.getText().toString())){
                    Toast.makeText(MainActivity.this,"text field is Empty",Toast.LENGTH_SHORT).show();
                    return;
                }
                else{
                    String data=te.getText().toString();
                    int speechstatus=tts.speak(data, TextToSpeech.QUEUE_FLUSH, null);
                    if(speechstatus==TextToSpeech.ERROR){
                        Log.e("TTS", "Error in converting Text to Speech!");
                    }

                }
            }
        });
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
    }
}
